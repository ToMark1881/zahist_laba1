import Foundation

let letters: [Character] = ["а", "б", "в", "г", "д", "е", "є", "ж", "з", "и", "і", "ї", "й", "к", "л", "м", "н", "о", "п", "р", "с", "т", "у", "ф", "х", "ц", "ч", "ш", "щ", "ь", "ю", "я"]
let surname = "вдовиченко"
let keyword = "метал"

func createMatrixFromCharacterArray(_ array: [Character]) -> [[Character]] {
    let count = array.count
    var workingArray = array
    var characters = Array(repeating: Array(repeating: Character("-"), count: count), count: count)
    for lineIndex in characters.indices {
        characters[lineIndex] = workingArray
        //modify array
        let first = workingArray.first ?? " "
        workingArray.remove(at: 0)
        workingArray.append(first)
    }
    return characters
}

let matrix = createMatrixFromCharacterArray(letters)

func makeKeywordCountEqualToSurnameCount(keyword: String, surname: String) -> String {
    var newKeyword = ""
    
    if keyword.count > surname.count {
        newKeyword = keyword
        while newKeyword.count != surname.count {
            newKeyword.removeLast(1)
        }
    }
    else if keyword.count < surname.count {
        newKeyword = keyword
        var index = 0
        let array = Array(keyword)
        while newKeyword.count != surname.count {
            newKeyword.append(array[index])
            index += 1
        }
    }
    else {
        newKeyword = keyword
    }
    return newKeyword
}
let newKeyword = makeKeywordCountEqualToSurnameCount(keyword: keyword, surname: surname)

func cipher(surname: String, keyWord: String, matrix: [[Character]], and letters: [Character]) -> String {
    var stringToReturn = ""
    for index in surname.indices {
        let letterInKeyword = keyWord[index]
        let letterInSurname = surname[index]
        let index1 = letters.firstIndex(of: letterInKeyword) ?? 0
        let index2 = letters.firstIndex(of: letterInSurname) ?? 0
        
        let letter = matrix[index1][index2]
        stringToReturn.append(letter)
    }
    
    return stringToReturn
}

let newSurname = cipher(surname: surname, keyWord: newKeyword, matrix: matrix, and: letters)
print(newSurname)

