import Foundation

let surname = "вдовиченко"


func createMatrixOfCharacters() -> [[Character]] {
    var characters = Array(repeating: Array(repeating: Character("-"), count: 5), count: 6) //матрица размером 5х6
    characters[0][0] = "а"
    characters[0][1] = "б"
    characters[0][2] = "в"
    characters[0][3] = "г"
    characters[0][4] = "д"
    characters[1][0] = "е"
    characters[1][1] = "ж"
    characters[1][2] = "з"
    characters[1][3] = "и"
    characters[1][4] = "к"
    characters[2][0] = "л"
    characters[2][1] = "м"
    characters[2][2] = "н"
    characters[2][3] = "о"
    characters[2][4] = "п"
    characters[3][0] = "р"
    characters[3][1] = "с"
    characters[3][2] = "т"
    characters[3][3] = "у"
    characters[3][4] = "ф"
    characters[4][0] = "х"
    characters[4][1] = "ц"
    characters[4][2] = "ч"
    characters[4][3] = "ш"
    characters[4][4] = "щ"
    characters[5][0] = "ы"
    characters[5][1] = "ю"
    characters[5][2] = "я"
    characters[5][3] = "1"
    characters[5][4] = "2"
    return characters
}

let letters = createMatrixOfCharacters()

func cipher(_ name: String, with letters: [[Character]]) -> String {
    var newName = ""
    for letter in name {
        var index1 = 0
        var index2 = 0
        for i in letters.indices {
            for j in letters[i].indices {
                if letter == letters[i][j] {
                    index1 = i
                    index2 = j
                    print(letter, i, j)
                }
            }
        }
        if index1 == 5 {
            index1 = 0
        }
        else {
            index1 += 1
        }
        
        let newLetter = letters[index1][index2]
        newName.append(newLetter)
    }
    
    return newName
}

let cipheredName = cipher(surname, with: letters)
print(cipheredName)
