let surname = "вдовиченко"
let letters = ["а", "б", "в", "г", "д", "е", "є", "ж", "з", "и", "і", "ї", "й", "к", "л", "м", "н", "о", "п", "р", "с", "т", "у", "ф", "х", "ц", "ч", "ш", "щ", "ь", "ю", "я"]


func ceasar(_ name: String, shift: Int) -> String {
    let unicodeScalars = name.unicodeScalars.map { UnicodeScalar(Int($0.value) + shift)! }
    return String(String.UnicodeScalarView(unicodeScalars))
}

let ceasarSurname = ceasar(surname, shift: 3) //1
let name = ceasar(ceasarSurname, shift: -3) //тест


