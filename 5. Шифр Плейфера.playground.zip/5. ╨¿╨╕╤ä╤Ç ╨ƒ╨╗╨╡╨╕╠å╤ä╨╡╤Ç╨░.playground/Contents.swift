import Foundation

let surname = "вдовиченко"
let letters: [Character] = ["а", "б", "в", "г", "д", "е", "є", "ж", "з", "и", "і", "ї", "й", "к", "л", "м", "н", "о", "п", "р", "с", "т", "у", "ф", "х", "ц", "ч", "ш", "щ", "ь", "ю", "я"]
var keyword = "жизньььььь"

func isRussianLetter(_ character: Character) -> Bool {
    return character.isLetter && character >= "а" && character <= "я"
}

func createTable() -> [Character] {
    var table = [Character]()
    var set = Set<Character>()
    let squeezed = keyword.filter{ set.insert($0).inserted }
    print(squeezed)
    for letter in squeezed {
        if letter != "\n" && isRussianLetter(letter) {
            table.append(letter)
        }
    }
    for char in letters {
        if !squeezed.contains(char) {
            table.append(char)
        }
    }
    return table
}

func findSquareFromCount(_ count: Int) -> Int {
    var square = 1
    while square*square <= count {
        square += 1
    }
    return square
}

func createMatrixOfCharactersFromArray(_ array: [Character]) -> [[Character]] {
    let count = array.count
    let rowCount = findSquareFromCount(count)
    var characters = Array(repeating: Array(repeating: Character("-"), count: rowCount), count: rowCount)
    var index = 0
    for i in characters.indices {
        for j in characters[i].indices {
            if index < array.count {
                characters[i][j] = array[index]
                index += 1
            }
        }
    }
    return characters
}

func addExtraSymbolTo(_ name: String) -> String {
    var name = name
    if name.count % 2 != 0 {
        name.append("я")
    }
    return name
}

func separateName(_ name: String) -> [String] {
    var nameArray = [String]()
    var workingString = String()
    for index in name.indices {
        workingString.append(name[index])
        if workingString.count == 2 {
            nameArray.append(workingString)
            workingString.removeAll()
        }
    }
    return nameArray
}

let workingName = separateName(addExtraSymbolTo(surname))

func modifyString(_ str: String, matrix: [[Character]]) -> String {
    var newStr = ""
    var firstIndexes = [Int]()
    var secondIndexes = [Int]()
    
    for ind in str.indices {
        var index1 = 0
        var index2 = 0
        for i in matrix.indices {
            for j in matrix[i].indices {
                if str[ind] == matrix[i][j] {
                    index1 = i
                    index2 = j
                }
            }
        }
        if str[ind] == str.first {
            firstIndexes = [index1, index2]
        }
        else {
            secondIndexes = [index1, index2]
        }
    }
    
    print(firstIndexes, secondIndexes)
    
    if firstIndexes[0] == secondIndexes[0] { //одна строка
        if secondIndexes[0] == 5 {
            newStr = "\(matrix[firstIndexes[0] + 1][firstIndexes[1]])\(matrix[0][secondIndexes[1]])"
        }
        else {
            newStr = "\(matrix[firstIndexes[0] + 1][firstIndexes[1]])\(matrix[secondIndexes[0] + 1][secondIndexes[1]])"
        }
    }
    else if firstIndexes[1] == secondIndexes[1] { //один столбец
        if secondIndexes[1] == 5 {
            newStr = "\(matrix[firstIndexes[0]][firstIndexes[1] + 1])\(matrix[0][secondIndexes[1] + 1])"
        }
        else {
            newStr = "\(matrix[firstIndexes[0]][firstIndexes[1] + 1])\(matrix[secondIndexes[0]][secondIndexes[1] + 1])"
        }
    }
    else { //не имеют ничего общего
        newStr = "\(matrix[firstIndexes[0] + 1][secondIndexes[1]])\(matrix[secondIndexes[0]][firstIndexes[1]])"
    }
    return newStr
}

func cipher(_ name: [String], matrix: [[Character]]) -> String {
    var newName = ""
    for str in name {
        newName.append(modifyString(str, matrix: matrix))
    }
    return newName
}
let newSurname = cipher(workingName, matrix: createMatrixOfCharactersFromArray(createTable()))
print(newSurname)

