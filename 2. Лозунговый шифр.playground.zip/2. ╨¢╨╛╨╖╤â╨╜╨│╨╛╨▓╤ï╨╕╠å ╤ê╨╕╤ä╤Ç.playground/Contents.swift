import Foundation

var table = [Character]()
let letters: [Character] = ["а", "б", "в", "г", "д", "е", "є", "ж", "з", "и", "і", "ї", "й", "к", "л", "м", "н", "о", "п", "р", "с", "т", "у", "ф", "х", "ц", "ч", "ш", "щ", "ь", "ю", "я"]
var slogan = "жизньььььь"
let surname = "вдовиченко"


func isRussianLetter(_ character: Character) -> Bool {
    return character.isLetter && character >= "а" && character <= "я"
}

func createTable() {
    var set = Set<Character>()
    let squeezed = slogan.filter{ set.insert($0).inserted }
    print(squeezed)
    for letter in squeezed {
        if letter != "\n" && isRussianLetter(letter) {
            table.append(letter)
        }
    }
    for char in letters {
        if !squeezed.contains(char) {
            table.append(char)
        }
    }
}

func cipher(_ name: String) -> String {
    var cipheredSurname = ""
    for char in name {
        let index = letters.firstIndex(of: char) ?? 0
        let newLetter = table[index]
        cipheredSurname.append(newLetter)
    }
    return cipheredSurname
}

createTable()
print(cipher(surname))




