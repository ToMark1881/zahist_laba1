import Foundation

let surname = "вдовиченко"
let letters: [Character] = ["а", "б", "в", "г", "д", "е", "є", "ж", "з", "и", "і", "ї", "й", "к", "л", "м", "н", "о", "п", "р", "с", "т", "у", "ф", "х", "ц", "ч", "ш", "щ", "ь", "ю", "я"]
var keyword = "жизньььььь"

func isRussianLetter(_ character: Character) -> Bool {
    return character.isLetter && character >= "а" && character <= "я"
}

func createTable() -> [Character] {
    var table = [Character]()
    var set = Set<Character>()
    let squeezed = keyword.filter{ set.insert($0).inserted }
    print(squeezed)
    for letter in squeezed {
        if letter != "\n" && isRussianLetter(letter) {
            table.append(letter)
        }
    }
    for char in letters {
        if !squeezed.contains(char) {
            table.append(char)
        }
    }
    return table
}

func findSquareFromCount(_ count: Int) -> Int {
    var square = 1
    while square*square <= count {
        square+=1
    }
    return square
}

func createMatrixOfCharactersFromArray(_ array: [Character]) -> [[Character]] {
    let count = array.count
    let rowCount = findSquareFromCount(count)
    var characters = Array(repeating: Array(repeating: Character("-"), count: rowCount), count: rowCount) //матрица размером 5х6
    var index = 0
    for i in characters.indices {
        for j in characters[i].indices {
            if index < array.count {
                characters[i][j] = array[index]
                index += 1
            }
        }
    }
    return characters
}


func cipher(_ name: String, with letters: [[Character]]) -> String {
    var newName = ""
    for letter in name {
        var index1 = 0
        var index2 = 0
        for i in letters.indices {
            for j in letters[i].indices {
                if letter == letters[i][j] {
                    index1 = i
                    index2 = j
                    print(letter, i, j)
                }
            }
        }
        if index1 == 4 {
            index1 = 0
        }
        else {
            index1 += 1
        }
        
        let newLetter = letters[index1][index2]
        newName.append(newLetter)
    }
    
    return newName
}

let matrix = createMatrixOfCharactersFromArray(createTable())
let newName = cipher(surname, with: matrix)
print(newName)
