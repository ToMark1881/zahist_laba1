import Foundation

class Element {
    
    let letter: Character
    let firstNumber: Int
    let secondNumber: Int
    
    init(letter: Character, first: Int, second: Int) {
        self.letter = letter
        self.firstNumber = first
        self.secondNumber = second
    }
}

let letters: [Character] = ["а", "б", "в", "г", "д", "е", "є", "ж", "з", "и", "і", "ї", "й", "к", "л", "м", "н", "о", "п", "р", "с", "т", "у", "ф", "х", "ц", "ч", "ш", "щ", "ь", "ю", "я"]
let surname = "вдовиченко"
var elements = [Element]()

for letter in letters {
    let element = Element(letter: letter, first: Int.random(in: 0 ... 100), second: Int.random(in: 0 ... 100))
    elements.append(element)
}

func cipher(_ name: String) -> String {
    var stringToReturn = ""
    for letter in name {
        let randBool = Bool.random()
        
        for elem in elements {
            if elem.letter == letter {
                if randBool {
                    stringToReturn.append(elem.firstNumber.description + " ")
                }
                else {
                    stringToReturn.append(elem.secondNumber.description + " ")
                }
                break
            }
        }
        
    }
    return stringToReturn
}

for elem in elements {
    print("\(elem.letter) \(elem.firstNumber) \(elem.secondNumber);")
}

let newSurname = cipher(surname)
print(newSurname)


